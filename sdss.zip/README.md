# sdss-analysis-and-classification

Use of machine learning techniques for heavenly bodies classification based on Sloan Digital Sky Survey.